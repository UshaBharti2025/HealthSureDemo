
package com.infinite.jsf.admin.model;

public enum OtpStatus {
	INACTIVE,
    ACTIVE,
    EXPIRED
}
