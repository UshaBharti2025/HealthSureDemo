package com.infinite.jsf.insurance.controller;
//this controller manage the company related crud operation 
public class InsuranceCompanyController {

}
