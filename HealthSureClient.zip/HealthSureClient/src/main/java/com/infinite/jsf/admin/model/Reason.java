package com.infinite.jsf.admin.model;

public enum Reason {
	SIGNUP,
    FORGOT_PASSWORD
}