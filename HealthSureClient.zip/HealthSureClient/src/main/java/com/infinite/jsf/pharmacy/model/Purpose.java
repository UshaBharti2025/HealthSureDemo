package com.infinite.jsf.pharmacy.model;

public enum Purpose {

	REGISTER,FORGOT_PASSWORD;
}
