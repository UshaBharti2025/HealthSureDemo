package com.infinite.jsf.recipient.model;

public enum Gender {
	MALE,FEMALE
}
