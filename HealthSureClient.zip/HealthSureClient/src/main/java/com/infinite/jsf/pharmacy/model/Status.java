package com.infinite.jsf.pharmacy.model;

public enum Status {

	PENDING,VERIFIED,EXPIRED;
}
