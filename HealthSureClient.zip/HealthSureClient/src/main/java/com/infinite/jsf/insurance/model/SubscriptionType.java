package com.infinite.jsf.insurance.model;

public enum SubscriptionType {
	INDIVIDUAL, FAMILY, SELF
}
