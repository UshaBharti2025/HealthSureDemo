package com.infinite.jsf.pharmacy.controller;

public class UpdateMedicinesController {

}
