package com.infinite.jsf.insurance.model;

public enum SubscriptionStatus {
	ACTIVE, EXPIRED, SELF
}
