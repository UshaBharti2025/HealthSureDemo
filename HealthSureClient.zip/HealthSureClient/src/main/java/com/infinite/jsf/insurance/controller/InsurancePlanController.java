package com.infinite.jsf.insurance.controller;


//this controller contains all the method related to InsurancePlan
public class InsurancePlanController {

	
}
